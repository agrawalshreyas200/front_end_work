var randomNum1=Math.floor(Math.random()*6)+1;
var randomImageno1="dice"+randomNum1+".png";
var randomImagesrc="images/"+randomImageno1;

var image1=document.querySelectorAll(".img1")[0];
image1.setAttribute("src",randomImagesrc);

var randomNum2=Math.floor(Math.random()*6)+1;
var randomImageno2="dice"+randomNum2+".png";
var randomImagesrc2="images/"+randomImageno2;

var image1=document.querySelectorAll(".img2")[0];
image1.setAttribute("src",randomImagesrc2);


if(randomNum1>randomNum2){
  document.querySelector("h1").innerHTML="Player 1 Wins";
}

else if (randomNum1==randomNum2) {
  document.querySelector("h1").innerHTML="Draw";

}

else{
  document.querySelector("h1").innerHTML="Player 2 Wins";
}
